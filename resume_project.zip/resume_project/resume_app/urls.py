# from django.urls import path
# from . import views

# urlpatterns = [
#     path('', views.form_view, name='form_view'),
#     path('login/', views.login_view, name='login'),
#     path('register/', views.register_view, name='register'),
    
#     path('generate_pdf/', views.generate_pdf, name='generate_pdf'),
# ]

from django.urls import path
from .views import form_view, register_view, login_view ,forgot_password_view # Import your views

urlpatterns = [
    path('form/', form_view, name='form'),  # Ensure you have this pattern
    path('register/', register_view, name='register'),
    path('', login_view, name='login'),
    path('forgot-password/', forgot_password_view, name='forgot_password'),
]


