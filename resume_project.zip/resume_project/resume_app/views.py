from django.shortcuts import render
from django.http import FileResponse
from reportlab.lib.pagesizes import A4
from reportlab.pdfgen import canvas
from reportlab.lib.units import inch
import io
from reportlab.lib import colors
from .forms import RegistrationForm
def form_view(request):
    if request.method == 'POST':
        return generate_pdf(request)
    return render(request, 'resume_app/form.html')

def generate_pdf(request):
    buffer = io.BytesIO()
    pdf_canvas = canvas.Canvas(buffer, pagesize=A4)
    width, height = A4

    # Set margins
    margin_x = inch * 0.5
    margin_y = inch * 0.5
    line_height = 14
    y = height - margin_y

    # Name at the top middle
    name = request.POST.get('name', 'Name Not Provided')
    pdf_canvas.setFont("Helvetica-Bold", 22)
    name_width = pdf_canvas.stringWidth(name, "Helvetica-Bold", 22)
    pdf_canvas.drawString((width - name_width) / 2, y, name)
    y -= line_height + 8  # Space below the name

    # Contact information
    pdf_canvas.setFont("Helvetica", 12)
    pdf_canvas.setFillColor(colors.black)

    # Contact information items
    phone = request.POST.get('phone', '+91 9121425295')
    location = request.POST.get('location', 'India, A.P')
    linkedin_text = "LinkedIn"
    linkedin_url = request.POST.get('linkedin', '#')
    github_text = "GitHub"
    github_url = request.POST.get('github', '#')
    email_text = "Email"
    email = request.POST.get('email', 'No email provided.')

    items = [
        (phone, None),              
        (location, None),           
        (linkedin_text, linkedin_url),  
        (github_text, github_url),      
        (email_text, f"mailto:{email}") 
    ]

    # Calculate width for centering
    total_items_width = sum(pdf_canvas.stringWidth(item[0], "Helvetica", 12) for item in items)
    total_separator_width = 3 * pdf_canvas.stringWidth(" | ", "Helvetica", 12)  # Separators
    total_width = total_items_width + total_separator_width

    current_x = (width - total_width) / 2

    for i, (text, url) in enumerate(items):
        text_width = pdf_canvas.stringWidth(text, "Helvetica", 12)
        pdf_canvas.drawString(current_x, y, text)

        if url:
            pdf_canvas.linkURL(url, (current_x, y - 3, current_x + text_width, y + 10), relative=1)

        if i < len(items) - 1:
            separator = " | "
            pdf_canvas.drawString(current_x + text_width + 5, y, separator)
            current_x += text_width + 5 + pdf_canvas.stringWidth(separator, "Helvetica", 12)
        else:
            current_x += text_width + 5

    y -= line_height * 2  # Space before the next section

    # Function to draw section content
    def draw_section(title, content):
        nonlocal y
        pdf_canvas.setFont("Helvetica-Bold", 12)

        # Draw title
        pdf_canvas.drawString(margin_x, y, title)
        y -= line_height / 2  # Space between title and line

        # Draw line below the title
        pdf_canvas.line(margin_x, y, width - margin_x, y)
        y -= line_height * 1.5  # Space before content

        # Set font for content
        pdf_canvas.setFont("Helvetica", 10)

        # Split content into lines and wrap text
        content_lines = content.splitlines()

        for line in content_lines:
            words = line.split(' ')
            current_line = ""

            for word in words:
                # Check if adding the new word exceeds the max width
                test_line = current_line + (word + " " if current_line else word + " ")
                line_width = pdf_canvas.stringWidth(test_line.strip(), "Helvetica", 10)

                if line_width <= (width - margin_x * 2):
                    current_line = test_line
                else:
                    # Draw the current line and start a new line with the new word
                    pdf_canvas.drawString(margin_x, y, current_line.strip())
                    y -= line_height
                    current_line = word + " "

            # Draw any remaining text in the current line
            if current_line:
                pdf_canvas.drawString(margin_x, y, current_line.strip())
                y -= line_height

        y -= line_height * 1.5  # Space after each section

        # If the y position is too low, add a new page
        if y < margin_y:
            pdf_canvas.showPage()
            y = height - margin_y  # Reset y position for new page

    # Objective
    draw_section("Objective:", request.POST.get('objective', ''))

    # Education
    draw_section("Education:", request.POST.get('education', 'No education details provided.'))

    # Skills
    draw_section("Skills:", request.POST.get('skills', 'No skills provided.'))

    # Experience / Internship
    draw_section("Experience / Internship:", request.POST.get('experience', 'No experience details provided.'))

    # Projects
    draw_section("Projects:", request.POST.get('projects', 'No project details provided.'))

    # Extra-Curricular Activities
    draw_section("Extra-Curricular Activities:", request.POST.get('activities', 'No extra-curricular activities provided.'))

    pdf_canvas.showPage()
    pdf_canvas.save()
    buffer.seek(0)
    return FileResponse(buffer, as_attachment=True, filename="resume.pdf")

from django.contrib.auth.models import User
from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login
from .forms import LoginForm

def register_view(request):
    if request.method == 'POST':
        form = RegistrationForm(request.POST)
        if form.is_valid():
            user = User.objects.create_user(
                username=form.cleaned_data['email'],
                email=form.cleaned_data['email'],
                password=form.cleaned_data['password']
            )
            user.save()
            return redirect('login')  # Redirect to login after successful registration
    else:
        form = RegistrationForm()
    
    return render(request, 'resume_app/register.html', {'form': form})


def login_view(request):
    if request.method == 'POST':
        form = LoginForm(request.POST)
        if form.is_valid():
            email = form.cleaned_data['email']
            password = form.cleaned_data['password']
            user = authenticate(request, username=email, password=password)  # Assuming email is used as username
            if user is not None:
                login(request, user)
                return redirect('form')  # Redirect to home page or another page
            else:
                form.add_error(None, 'Invalid email or password.')
    else:
        form = LoginForm()
    
    return render(request, 'resume_app/login.html', {'form': form})

# views.py
# views.py
# resume_app/views.py

from django.shortcuts import render, redirect
from django.contrib import messages
from django.core.mail import send_mail
from django.conf import settings
from django.contrib.auth.models import User  # Assuming you're using Django's built-in User model

def forgot_password_view(request):
    if request.method == 'POST':
        email = request.POST.get('email')
        
        try:
            user = User.objects.get(email=email)
            # Logic to send password reset email
            send_mail(
                'Password Reset Request',
                'Here is the link to reset your password.',
                settings.DEFAULT_FROM_EMAIL,
                [email],
                fail_silently=False,
            )
            messages.success(request, 'Password reset link sent to your email.')
            return redirect('login')  # Redirect to login after sending email
        except User.DoesNotExist:
            messages.error(request, 'Email address not found.')
    
    return render(request, 'resume_app/forgot_password.html')

