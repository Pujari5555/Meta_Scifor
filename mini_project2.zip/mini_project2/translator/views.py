from django.shortcuts import render, redirect
from googletrans import Translator
from gtts import gTTS
from django.conf import settings
import os
import uuid

# Define the allowed Indian languages
INDIAN_LANGUAGES = {
    'hi': 'Hindi',
    'bn': 'Bengali',
    'te': 'Telugu',
    'mr': 'Marathi',
    'ta': 'Tamil',
    'gu': 'Gujarati',
    'pa': 'Punjabi',
    'ml': 'Malayalam',
    'kn': 'Kannada',
    'or': 'Odia',
}

def translate_and_speak(request):
    translated_text = None
    source_language = None
    target_language = None
    audio_file_url = None
    error_message = None

    if request.method == "POST":
        text = request.POST.get("text", "")
        target_language = request.POST.get("language", "")
        translator = Translator()

        try:
            # Perform translation
            translation = translator.translate(text, dest=target_language)
            translated_text = translation.text
            source_language = translation.src

            # Generate unique audio filename
            unique_filename = f"translated_audio_{uuid.uuid4().hex}.mp3"
            audio_file_path = os.path.join(settings.MEDIA_ROOT, unique_filename)

            # Generate speech from translated text
            tts = gTTS(translated_text, lang=target_language, slow=False)
            tts.save(audio_file_path)

            # Create URL for the audio file
            audio_file_url = settings.MEDIA_URL + unique_filename

            # Store results in session to persist through redirect
            request.session['translated_text'] = translated_text
            request.session['source_language'] = source_language
            request.session['target_language'] = target_language
            request.session['audio_file_url'] = audio_file_url

            return redirect('translate_and_speak')  # Redirect to prevent re-submission
        except Exception as e:
            error_message = f"An error occurred: {e}"

    # Retrieve session data for display
    translated_text = request.session.pop('translated_text', None)
    source_language = request.session.pop('source_language', None)
    target_language = request.session.pop('target_language', None)
    audio_file_url = request.session.pop('audio_file_url', None)

    return render(request, "translator/index.html", {
        "languages": INDIAN_LANGUAGES,
        "translated_text": translated_text,
        "source_language": source_language,
        "target_language": target_language,
        "audio_file_url": audio_file_url,
        "error_message": error_message,
    })
