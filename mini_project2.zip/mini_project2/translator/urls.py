from django.urls import path
from . import views

urlpatterns = [
    path("", views.translate_and_speak, name="translate_and_speak"),
]
