from django.urls import path
from . import views
from resume_builder import views as user_view
from django.contrib.auth import views as auth_views

urlpatterns = [
    path('', views.index, name='index'),
    path('accounts/login/', auth_views.LoginView.as_view(template_name='resume_builder/login.html', next_page='/'), name='login'),
    path('form/', user_view.form_view, name='form'),
    path('register/', user_view.register, name='register'),
    path('logout/', auth_views.LogoutView.as_view(template_name='resume_builder/index.html'), name='logout'),
]

from django.conf import settings
from django.conf.urls.static import static

if settings.DEBUG:
    urlpatterns += static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)
