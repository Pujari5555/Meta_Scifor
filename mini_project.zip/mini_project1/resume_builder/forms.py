from django import forms
from django.db import models
from django.contrib.auth.models import User
from django.contrib.auth.forms import UserCreationForm

class Profile(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    phone_no = models.CharField(max_length=20)

class UserRegisterForm(UserCreationForm):
    email = forms.EmailField()
    full_name = forms.CharField(max_length=40, label='Full Name')

    class Meta:
        model = User
        fields = ['username', 'email', 'full_name', 'password1', 'password2']

    def save(self, commit=True):
        user = super().save(commit=False)
        # Split the full_name into first_name and last_name
        full_name = self.cleaned_data.get('full_name')
        if full_name:
            names = full_name.split(' ', 1)  # Split into first and last name
            user.first_name = names[0]
            user.last_name = names[1] if len(names) > 1 else ''  # Handle case where there's no last name
        user.email = self.cleaned_data.get('email')
        if commit:
            user.save()
            # No need to save phone_no in Profile model anymore
        return user


class EducationForm(forms.Form):
    degree = forms.CharField(label="Degree", required=True)
    field = forms.CharField(label="Field", required=True)
    institute = forms.CharField(label="Institute", required=True)
    start_year = forms.IntegerField(label="Start Year", required=True)
    end_year = forms.IntegerField(label="End Year", required=True)
    cgpa = forms.DecimalField(label="CGPA", required=False)

class SkillForm(forms.Form):
    category = forms.CharField(label="Skill Category", required=True)
    skills = forms.CharField(label="Skills", required=True, help_text="Separate multiple skills with commas")

class ExperienceForm(forms.Form):
    company = forms.CharField(label="Company", required=True)
    role = forms.CharField(label="Role", required=True)
    start_date = forms.DateField(label="Start Date", required=True, widget=forms.SelectDateWidget)
    end_date = forms.DateField(label="End Date", required=False, widget=forms.SelectDateWidget)
    responsibilities = forms.CharField(widget=forms.Textarea, required=False)

class ProjectForm(forms.Form):
    project_name = forms.CharField(label="Project Name", required=True)
    description = forms.CharField(widget=forms.Textarea, required=False)

class ResumeForm(forms.Form):
    name = forms.CharField(label="Name", required=True)
    phone = forms.CharField(label="Phone", required=True)
    email = forms.EmailField(label="Email", required=True)
    linkedin = forms.URLField(label="LinkedIn Profile Link", required=False)
    github = forms.URLField(label="GitHub Profile Link", required=False)
    location = forms.CharField(label="Location", required=False)
    objective = forms.CharField(widget=forms.Textarea, label="Objective", required=False)
    education = forms.CharField(widget=forms.HiddenInput(), required=False)
    skills = forms.CharField(widget=forms.HiddenInput(), required=False)
    experience = forms.CharField(widget=forms.HiddenInput(), required=False)
    projects = forms.CharField(widget=forms.HiddenInput(), required=False)
    activities=forms.CharField(widget=forms.HiddenInput(), required=False)
class RegistrationForm(forms.ModelForm):
    password = forms.CharField(label='Password', widget=forms.PasswordInput)
    password_confirm = forms.CharField(label='Confirm Password', widget=forms.PasswordInput)

    class Meta:
        model = User  # Use your user model
        fields = ['email']

    def clean(self):
        cleaned_data = super().clean()
        password = cleaned_data.get('password')
        password_confirm = cleaned_data.get('password_confirm')
        
        if password != password_confirm:
            raise forms.ValidationError("Passwords do not match.")

class LoginForm(forms.Form):
    email = forms.EmailField(label='Email', max_length=100)
    password = forms.CharField(label='Password', widget=forms.PasswordInput)