from django.shortcuts import render, redirect
from django.contrib import messages
from django.contrib.auth import authenticate, login
from django.contrib.auth.decorators import login_required
from django.contrib.auth.forms import AuthenticationForm
from .forms import UserRegisterForm
from django.core.mail import send_mail
from django.core.mail import EmailMultiAlternatives
from django.template.loader import get_template
from django.template import Context
from reportlab.pdfgen import canvas
from reportlab.lib.units import inch
from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from django.http import FileResponse
import io

def index(request):
	return render(request, 'resume_builder/index.html', {'title':'index'})


def register(request):
    if request.method == 'POST':
        form = UserRegisterForm(request.POST)
        if form.is_valid():
            form.save()
            username = form.cleaned_data.get('username')
            email = form.cleaned_data.get('email')
            messages.success(request, f'Your account has been created! You are now able to log in.')
            return redirect('login')
        else:
            print(form.errors) 
    else:
        form = UserRegisterForm()
    
    return render(request, 'resume_builder/register.html', {'form': form, 'title': 'Register Here'})

def Login(request):
	if request.method == 'POST':
		username = request.POST['username']
		password = request.POST['password']
		user = authenticate(request, username = username, password = password)
		if user is not None:
			login(request, user)
			messages.success(request, f' welcome {username} !!')
			return redirect('index')
		else:
			messages.info(request, f'account done not exit plz sign in')
	form = AuthenticationForm()
	return render(request, 'resume_builder/login.html', {'form':form, 'title':'log in'})

@login_required
def form_view(request):
    if request.method == 'POST':
        return generate_pdf(request)
    return render(request, 'resume_builder/form.html')

def generate_pdf(request):
    buffer = io.BytesIO()
    pdf_canvas = canvas.Canvas(buffer, pagesize=A4)
    width, height = A4


    margin_x = inch * 0.5
    margin_y = inch * 0.5
    line_height = 14
    section_gap = 24
    y = height - margin_y

    name = request.POST.get('name', 'Name Not Provided')
    pdf_canvas.setFont("Helvetica-Bold", 22)
    name_width = pdf_canvas.stringWidth(name, "Helvetica-Bold", 22)
    pdf_canvas.drawString((width - name_width) / 2, y, name)
    y -= line_height + 10

    contact_info = [
        request.POST.get('phone', 'Phone Not Provided'),
        request.POST.get('location', 'Location Not Provided'),
        "LinkedIn",
        "GitHub",
        "Email"
    ]
    links = {
        "LinkedIn": request.POST.get('linkedin', 'https://www.linkedin.com'),
        "GitHub": request.POST.get('github', 'https://github.com'),
        "Email": request.POST.get('email', 'mailto:example@example.com')
    }

    pdf_canvas.setFont("Helvetica", 12)
    total_contact_width = sum(pdf_canvas.stringWidth(item, "Helvetica", 12) + 20 for item in contact_info[:-1])
    total_contact_width += pdf_canvas.stringWidth(contact_info[-1], "Helvetica", 12)
    x_start = (width - total_contact_width) / 2

    for item in contact_info:
        text_width = pdf_canvas.stringWidth(item, "Helvetica", 12)
        pdf_canvas.drawString(x_start, y, item)
        if item in links:
            pdf_canvas.linkURL(links[item], (x_start, y - 3, x_start + text_width, y + 10), relative=1)
        x_start += text_width + 20  

    y -= line_height + section_gap

    def draw_section(title, content):
        nonlocal y
        pdf_canvas.setFont("Helvetica-Bold", 12)
        pdf_canvas.drawString(margin_x, y, title)
        y -= line_height / 2
        pdf_canvas.line(margin_x, y, width - margin_x, y)
        y -= line_height * 1.5
        pdf_canvas.setFont("Helvetica", 10)

        lines = content.split('\n')
        for line in lines:
            words = line.split()
            current_line = ""
            for word in words:
                if pdf_canvas.stringWidth(current_line + word, "Helvetica", 10) > (width - 2 * margin_x):
                    pdf_canvas.drawString(margin_x, y, current_line)
                    y -= line_height
                    current_line = ""
                current_line += word + " "
            if current_line:
                pdf_canvas.drawString(margin_x, y, current_line)
                y -= line_height

            if y < margin_y:  
                pdf_canvas.showPage()
                y = height - margin_y

        y -= section_gap

    sections = {
        "Objective": request.POST.get('objective', 'No objective provided.'),
        "Education": request.POST.get('education', 'No education details provided.'),
        "Skills": request.POST.get('skills', 'No skills listed.'),
        "Experience": request.POST.get('experience', 'No experience listed.'),
        "Projects": request.POST.get('projects', 'No projects listed.'),
        "Extra-Curricular Activities": request.POST.get('activities', 'No activities listed.')
    }

    for title, content in sections.items():
        draw_section(title, content)

    pdf_canvas.save()
    buffer.seek(0)
    return FileResponse(buffer, as_attachment=True, filename='resume.pdf')
